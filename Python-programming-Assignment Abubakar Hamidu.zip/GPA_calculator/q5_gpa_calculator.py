# ============================================================
# Q5 - Student Grade System (GPA Calculator)
# ============================================================

def score_to_grade(score):
    """Convert a numeric score to a letter grade."""
    if 70 <= score <= 100:
        return "A"
    elif 60 <= score <= 69:
        return "B"
    elif 50 <= score <= 59:
        return "C"
    elif 45 <= score <= 49:
        return "D"
    elif 40 <= score <= 44:
        return "E"
    else:
        return "F"

def grade_to_point(grade):
    """Convert a letter grade to its grade point."""
    points = {"A": 5, "B": 4, "C": 3, "D": 2, "E": 1, "F": 0}
    return points[grade]

def get_valid_score(prompt):
    """Prompt until the user enters a score between 0 and 100."""
    while True:
        try:
            score = float(input(prompt))
            if 0 <= score <= 100:
                return score
            print("Score must be between 0 and 100. Try again.")
        except ValueError:
            print("Invalid input. Enter a number.")

def get_valid_credit(prompt):
    """Prompt until the user enters a positive credit unit."""
    while True:
        try:
            credit = int(input(prompt))
            if credit > 0:
                return credit
            print("Credit unit must be a positive whole number.")
        except ValueError:
            print("Invalid input. Enter a whole number.")

def calculate_gpa(courses):
    """
    Calculate GPA from a list of course dictionaries.
    Each dict has keys: name, score, credit, grade, grade_point.
    """
    total_weighted_points = sum(c["grade_point"] * c["credit"] for c in courses)
    total_credits = sum(c["credit"] for c in courses)
    return total_weighted_points / total_credits if total_credits > 0 else 0.0

def display_transcript(courses, gpa):
    """Print a formatted transcript table."""
    print("\n" + "=" * 62)
    print("                  ACADEMIC TRANSCRIPT")
    print("=" * 62)
    print(f"{'Course':<12} {'Score':>6} {'Credit':>7} {'Grade':>6} {'Grade Pt':>9} {'Weighted':>9}")
    print("-" * 62)
    for c in courses:
        weighted = c["grade_point"] * c["credit"]
        print(f"{c['name']:<12} {c['score']:>6.1f} {c['credit']:>7} {c['grade']:>6} {c['grade_point']:>9} {weighted:>9}")
    print("-" * 62)
    total_credits = sum(c["credit"] for c in courses)
    total_weighted = sum(c["grade_point"] * c["credit"] for c in courses)
    print(f"{'TOTALS':<12} {'':>6} {total_credits:>7} {'':>6} {'':>9} {total_weighted:>9}")
    print("=" * 62)
    print(f"  Final GPA = {gpa:.2f}  /  5.00")

    # Classify the GPA
    if gpa >= 4.50:
        classification = "First Class Honours"
    elif gpa >= 3.50:
        classification = "Second Class Upper (2:1)"
    elif gpa >= 2.40:
        classification = "Second Class Lower (2:2)"
    elif gpa >= 1.50:
        classification = "Third Class"
    else:
        classification = "Pass / Fail"

    print(f"  Classification: {classification}")
    print("=" * 62)

def main():
    print("=" * 50)
    print("    STUDENT GRADE SYSTEM — GPA CALCULATOR")
    print("=" * 50)

    while True:
        courses = []

        try:
            num_courses = int(input("\nHow many courses do you want to enter? "))
            if num_courses <= 0:
                print("Number of courses must be at least 1.")
                continue
        except ValueError:
            print("Please enter a valid whole number.")
            continue

        for i in range(1, num_courses + 1):
            print(f"\n--- Course {i} of {num_courses} ---")
            name        = input("  Course name  : ").strip().upper() or f"COURSE{i}"
            score       = get_valid_score("  Score (0–100): ")
            credit      = get_valid_credit("  Credit unit  : ")
            grade       = score_to_grade(score)
            grade_point = grade_to_point(grade)

            print(f"  Grade: {grade}  (Grade Point: {grade_point})")

            courses.append({
                "name":        name,
                "score":       score,
                "credit":      credit,
                "grade":       grade,
                "grade_point": grade_point,
            })

        gpa = calculate_gpa(courses)
        display_transcript(courses, gpa)

        again = input("\nCalculate GPA for another student? (yes/no): ").strip().lower()
        if again != "yes":
            print("\nGoodbye!")
            break

# Entry point
if __name__ == "__main__":
    main()
