# ============================================================
# Q3 - Simple Calculator
# ============================================================

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    """Divide a by b. Returns error message if b is zero."""
    if b == 0:
        return "Error: Division by zero is not allowed."
    return a / b

def get_number(prompt):
    """Prompt user for a valid number (int or float)."""
    while True:
        try:
            return float(input(prompt))
        except ValueError:
            print("Invalid input. Please enter a valid number.")

def display_menu():
    print("\n" + "=" * 40)
    print("         SIMPLE CALCULATOR")
    print("=" * 40)
    print("  1. Addition")
    print("  2. Subtraction")
    print("  3. Multiplication")
    print("  4. Division")
    print("  5. Exit")
    print("=" * 40)

def main():
    while True:
        display_menu()
        choice = input("Choose operation (1-5): ").strip()

        if choice == "5":
            print("Goodbye!")
            break

        if choice not in ("1", "2", "3", "4"):
            print("Invalid choice. Please select 1 to 5.")
            continue

        num1 = get_number("Enter first number : ")
        num2 = get_number("Enter second number: ")

        if choice == "1":
            result = add(num1, num2)
            op_name = "Addition"
        elif choice == "2":
            result = subtract(num1, num2)
            op_name = "Subtraction"
        elif choice == "3":
            result = multiply(num1, num2)
            op_name = "Multiplication"
        else:
            result = divide(num1, num2)
            op_name = "Division"

        print(f"\nOperation : {op_name}")
        print(f"Numbers   : {num1} and {num2}")

        if isinstance(result, str):
            # Division by zero error message
            print(f"Result    : {result}")
        else:
            # Format cleanly: show int when result has no decimal part
            formatted = int(result) if result == int(result) else round(result, 6)
            print(f"Result    = {formatted}")

        again = input("\nPerform another calculation? (yes/no): ").strip().lower()
        if again != "yes":
            print("Goodbye!")
            break

# Entry point
if __name__ == "__main__":
    main()
