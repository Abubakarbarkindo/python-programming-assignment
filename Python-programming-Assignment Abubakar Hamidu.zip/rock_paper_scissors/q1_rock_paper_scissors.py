# ============================================================
# Q1 - Rock, Paper, Scissors Game
# ============================================================

import random

def get_computer_choice():
    """Randomly select computer's choice."""
    return random.choice(["rock", "paper", "scissors"])

def determine_winner(user, computer):
    """Determine the winner based on game rules."""
    if user == computer:
        return "It's a tie!"
    wins = {"rock": "scissors", "scissors": "paper", "paper": "rock"}
    if wins[user] == computer:
        return "You win!"
    return "Computer wins!"

def play_game():
    """Main game loop."""
    print("=" * 40)
    print("   ROCK, PAPER, SCISSORS GAME")
    print("=" * 40)

    user_score = 0
    computer_score = 0
    rounds = 0

    while True:
        print("\nChoices: rock | paper | scissors")
        user_choice = input("Enter your choice: ").strip().lower()

        if user_choice not in ["rock", "paper", "scissors"]:
            print("Invalid choice! Please enter rock, paper, or scissors.")
            continue

        computer_choice = get_computer_choice()
        rounds += 1

        print(f"\nYou chose   : {user_choice}")
        print(f"Computer chose: {computer_choice}")

        result = determine_winner(user_choice, computer_choice)
        print(f"Result      : {result}")

        if result == "You win!":
            user_score += 1
        elif result == "Computer wins!":
            computer_score += 1

        print(f"\nScore → You: {user_score}  |  Computer: {computer_score}  |  Rounds: {rounds}")

        again = input("\nPlay another round? (yes/no): ").strip().lower()
        if again != "yes":
            break

    print("\n" + "=" * 40)
    print("GAME OVER")
    print(f"Final Score → You: {user_score}  |  Computer: {computer_score}")
    if user_score > computer_score:
        print("Overall Winner: YOU! Well played!")
    elif computer_score > user_score:
        print("Overall Winner: Computer. Better luck next time!")
    else:
        print("Overall Result: It's a draw!")
    print("=" * 40)

# Entry point
if __name__ == "__main__":
    play_game()
