# ============================================================
# Q2 - Caesar Cipher Program
# ============================================================

def encrypt(message, shift):
    """Encrypt a message using Caesar Cipher."""
    encrypted = ""
    for char in message:
        if char == " ":
            encrypted += " "                  # preserve spaces
        elif char.isalpha():
            base = ord("A") if char.isupper() else ord("a")
            encrypted += chr((ord(char) - base + shift) % 26 + base)
        else:
            encrypted += char                 # keep digits / symbols as-is
    return encrypted

def decrypt(message, shift):
    """Decrypt a Caesar Cipher message (shift in reverse)."""
    return encrypt(message, -shift)

def main():
    print("=" * 40)
    print("      CAESAR CIPHER PROGRAM")
    print("=" * 40)

    while True:
        print("\nOptions:")
        print("  1. Encrypt a message")
        print("  2. Decrypt a message")
        print("  3. Exit")

        choice = input("\nSelect an option (1/2/3): ").strip()

        if choice == "3":
            print("Goodbye!")
            break

        if choice not in ("1", "2"):
            print("Invalid option. Please choose 1, 2, or 3.")
            continue

        message = input("Enter message: ")

        while True:
            try:
                shift = int(input("Enter shift value: "))
                break
            except ValueError:
                print("Shift value must be a whole number. Try again.")

        if choice == "1":
            result = encrypt(message, shift)
            print(f"\nOriginal message  : {message}")
            print(f"Encrypted message : {result}")
        else:
            result = decrypt(message, shift)
            print(f"\nEncrypted message : {message}")
            print(f"Decrypted message : {result}")

        again = input("\nDo another operation? (yes/no): ").strip().lower()
        if again != "yes":
            print("Goodbye!")
            break

# Entry point
if __name__ == "__main__":
    main()
