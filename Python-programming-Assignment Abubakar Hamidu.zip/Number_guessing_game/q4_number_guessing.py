# ============================================================
# Q4 - Number Guessing Game
# ============================================================

import random

def play_round():
    """Play one round of the guessing game. Returns number of attempts."""
    secret = random.randint(1, 100)
    attempts = 0

    print("\nI have picked a number between 1 and 100. Can you guess it?")

    while True:
        while True:
            try:
                guess = int(input("Guess a number between 1 and 100: "))
                if 1 <= guess <= 100:
                    break
                print("Please enter a number between 1 and 100.")
            except ValueError:
                print("Invalid input. Enter a whole number.")

        attempts += 1

        if guess < secret:
            print("Too low!  Try a higher number.")
        elif guess > secret:
            print("Too high! Try a lower number.")
        else:
            print(f"\nCorrect! You guessed the number in {attempts} attempt{'s' if attempts != 1 else ''}.")
            return attempts

def rating(attempts):
    """Give the player a performance rating."""
    if attempts <= 5:
        return "Excellent! You're a mind reader!"
    elif attempts <= 8:
        return "Good job! Nice guessing."
    elif attempts <= 12:
        return "Not bad. Keep practising!"
    else:
        return "Took a while, but you got there!"

def main():
    print("=" * 45)
    print("        NUMBER GUESSING GAME")
    print("=" * 45)

    total_rounds = 0
    total_attempts = 0

    while True:
        attempts = play_round()
        total_rounds += 1
        total_attempts += attempts

        print(rating(attempts))
        print(f"\nStats so far → Rounds played: {total_rounds} | "
              f"Total guesses: {total_attempts} | "
              f"Average: {total_attempts / total_rounds:.1f} guesses/round")

        again = input("\nPlay again? (yes/no): ").strip().lower()
        if again != "yes":
            print("\nThanks for playing! Goodbye!")
            print("=" * 45)
            break

# Entry point
if __name__ == "__main__":
    main()
